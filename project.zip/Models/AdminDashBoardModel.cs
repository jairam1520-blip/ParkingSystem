﻿namespace ParkingSystem.Models
{
    public class AdminDashBoardModel
    {
        public int BookingCount { get; set; }
        public int UserCount { get; set; }
        public int SlotCount { get; set; }
    }
}
